<?php

class Posisi extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        admincek();
    }
    public function index()
    {

        $data['posisi'] = $this->fb->db()->getReference('position')->getValue();
        $data['tittle'] = 'Posisi';
        $data['_view'] = 'posisi/index';
        $this->load->view('layouts/main', $data);
    }
}
