<?php

class Karyawan extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        authcek();
    }
    public function index()
    {
        admincek();
        $data['karyawan'] = $this->fb->db()->getReference('karyawan')->getValue();
        $data['tittle'] = 'Karyawan';
        $data['_view'] = 'karyawan/index';
        $this->load->view('layouts/main', $data);
    }
    public function add()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('email', 'Email', 'required|max_length[100]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[3]');
        $this->form_validation->set_rules('role', 'Role', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        if ($this->form_validation->run()) {
            $params = array(
                'email' => $this->input->post('email'),
                'password' => $this->input->post('password'),
                'role' => $this->input->post('role'),
                'nama' => $this->input->post('nama'),
            );
            $ref = 'user';
            $post = $this->fb->db()->getReference($ref)->push($params);
            if ($post) {
                echo "berhasil";
            } else {
                echo "gagal";
            }
        } else {
            $data['position']  = $this->fb->db()->getReference('position')->getValue();
            $data['unit']  = $this->fb->db()->getReference('unit')->getValue();
            $data['strata']  = $this->fb->db()->getReference('strata')->getValue();
            $data['ps_group']  = $this->fb->db()->getReference('ps_group')->getValue();
            $data['tittle'] = 'Tambah Data Karyawan';
            $data['_view'] = 'karyawan/add';
            $this->load->view('layouts/main', $data);
        }
    }
    public function edit($uid)
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('email', 'Email', 'required|max_length[100]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[3]');
        $this->form_validation->set_rules('role', 'Role', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');

        if ($this->form_validation->run()) {
            $params = array(
                'email' => $this->input->post('email'),
                'password' => $this->input->post('password'),
                'role' => $this->input->post('role'),
                'nama' => $this->input->post('nama'),
            );
            $ref = 'user';
            $post = $this->fb->db()->getReference($ref)->push($params);
            if ($post) {
                echo "berhasil";
            } else {
                echo "gagal";
            }
        } else {
            $data['position']  = $this->fb->db()->getReference('position')->getValue();
            $data['unit']  = $this->fb->db()->getReference('unit')->getValue();
            $data['strata']  = $this->fb->db()->getReference('strata')->getValue();
            $data['ps_group']  = $this->fb->db()->getReference('ps_group')->getValue();

            $ref = 'karyawan/' . $uid;
            $data['karyawan'] = $this->fb->db()->getReference($ref)->getValue();
            $data['tittle'] = 'Edit Data Karyawan';
            $data['_view'] = 'karyawan/edit';
            $this->load->view('layouts/main', $data);
        }
    }
}
