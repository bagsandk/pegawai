<?php

class Grup extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        admincek();
    }
    public function index()
    {
        $data['ps_group'] = $this->fb->db()->getReference('ps_group')->getValue();
        $data['tittle'] = 'PS Grup';
        $data['_view'] = 'grup/index';
        $this->load->view('layouts/main', $data);
    }
}
