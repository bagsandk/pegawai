<?php

class Unit extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        admincek();
    }
    public function index()
    {
        $data['unit'] = $this->fb->db()->getReference('unit')->getValue();
        $data['tittle'] = 'Unit';
        $data['_view'] = 'unit/index';
        $this->load->view('layouts/main', $data);
    }
}
