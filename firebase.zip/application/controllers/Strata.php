<?php

class Strata extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        admincek();
    }
    public function index()
    {
        $data['strata'] = $this->fb->db()->getReference('strata')->getValue();
        $data['tittle'] = 'Strata';
        $data['_view'] = 'strata/index';
        $this->load->view('layouts/main', $data);
    }
}
